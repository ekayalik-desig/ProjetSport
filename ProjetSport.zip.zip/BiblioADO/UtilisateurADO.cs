﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BiblioMetier;

namespace BiblioADO
{
    public class UtilisateurADO
    {
        public static void Ajouter(string login, string motDePasse)
        {
            login = login.Trim();

            if (login == "" || login.Length > 50)
            {
                throw new ArgumentException("Le login doit avoir entre 1 et 50 caractères.");
            }

            if (string.IsNullOrWhiteSpace(motDePasse) ||
                motDePasse.Length < 15 ||
                motDePasse.Length > 128)
            {
                throw new ArgumentException(
                    "Le mot de passe doit avoir entre 15 et 128 caractères.");
            }

            string sel = MotDePasse.CreerSel();
            string hash = MotDePasse.Hacher(motDePasse, sel);

            using (MySqlConnection cnx = ConnexionManager.GetConnection())
            {
                cnx.Open();

                string req =
                    "INSERT INTO Utilisateur (login, motDePasseHash, sel) " +
                    "VALUES (@login, @hash, @sel)";

                using (MySqlCommand cmd = new MySqlCommand(req, cnx))
                {
                    cmd.Parameters.AddWithValue("@login", login);
                    cmd.Parameters.AddWithValue("@hash", hash);
                    cmd.Parameters.AddWithValue("@sel", sel);

                    try
                    {
                        cmd.ExecuteNonQuery();
                    }
                    catch (MySqlException ex)
                    {
                        if (ex.Number == 1062)
                        {
                            throw new Exception("Ce login est déjà utilisé.");
                        }
                        else
                        {
                            throw;
                        }
                    }
                }
            }
        }
        public static bool VerifierConnexion(string login, string motDePasse)
        {
            bool connexionValide = false;

            using (MySqlConnection cnx = ConnexionManager.GetConnection())
            {
                cnx.Open();

                string req =
                    "SELECT motDePasseHash, sel FROM Utilisateur WHERE login = @login";

                using (MySqlCommand cmd = new MySqlCommand(req, cnx))
                {
                    cmd.Parameters.AddWithValue("@login", login.Trim());

                    using (MySqlDataReader lecteur = cmd.ExecuteReader())
                    {
                        if (lecteur.Read())
                        {
                            string hashEnregistre = lecteur.GetString(0);
                            string sel = lecteur.GetString(1);

                            string hashSaisi = MotDePasse.Hacher(motDePasse, sel);

                            if (hashSaisi == hashEnregistre)
                            {
                                connexionValide = true;
                            }
                        }
                    }
                }
            }

            return connexionValide;
        }
        public static bool ChangerMotDePasse(
    string login, string ancien, string nouveau)
        {
            bool modification = false;

            if (string.IsNullOrWhiteSpace(nouveau) ||
                nouveau.Length < 15 ||
                nouveau.Length > 128)
            {
                throw new ArgumentException(
                    "Le nouveau mot de passe doit avoir entre 15 et 128 caractères.");
            }

            bool connexionValide = VerifierConnexion(login, ancien);

            if (connexionValide == true)
            {
                string sel = MotDePasse.CreerSel();
                string hash = MotDePasse.Hacher(nouveau, sel);

                using (MySqlConnection cnx = ConnexionManager.GetConnection())
                {
                    cnx.Open();

                    string req =
                        "UPDATE Utilisateur " +
                        "SET motDePasseHash = @hash, sel = @sel " +
                        "WHERE login = @login";

                    using (MySqlCommand cmd = new MySqlCommand(req, cnx))
                    {
                        cmd.Parameters.AddWithValue("@hash", hash);
                        cmd.Parameters.AddWithValue("@sel", sel);
                        cmd.Parameters.AddWithValue("@login", login.Trim());

                        int nombre = cmd.ExecuteNonQuery();

                        if (nombre == 1)
                        {
                            modification = true;
                        }
                    }
                }
            }

            return modification;
        }
    }
}
    

