﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace BiblioMetier
{
    public class MotDePasse
    {
        public static string CreerSel()
        {
            byte[] sel = new byte[16];

            using (RandomNumberGenerator generateur =
                RandomNumberGenerator.Create())
            {
                generateur.GetBytes(sel);
            }

            return Convert.ToBase64String(sel);
        }

        public static string Hacher(string motDePasse, string sel)
        {
            byte[] selBytes = Convert.FromBase64String(sel);

            using (Rfc2898DeriveBytes calcul = new Rfc2898DeriveBytes(
                motDePasse, selBytes, 600000, HashAlgorithmName.SHA256))
            {
                return Convert.ToBase64String(calcul.GetBytes(32));
            }
        }
    }
}
    

